Research the topic "$ARGUMENTS" and write a short article about it — 200 to 250 words, accurate content, suitable for a general audience.

Then add it to `src/data/articles.js` following these steps:

1. Read `src/data/articles.js` to learn the current data structure and find the highest existing `id`.
2. Research the topic using WebSearch or WebFetch to gather accurate, up-to-date information.
3. Write the article:
   - Length: 200–250 words
   - Audience: general (no assumed technical knowledge)
   - Tone: informative and clear
   - Split into 3–4 short paragraphs
4. Add a new entry to the `articles` array with these fields, matching the existing structure exactly:
   - `id`: next integer after the current highest id
   - `title`: a clear, descriptive title for the topic
   - `summary`: one or two sentences describing what the article covers (used as a preview)
   - `content`: the full article text as a template literal, with blank lines between paragraphs
   - `author`: "Editorial Team"
   - `date`: today's date in YYYY-MM-DD format
5. Insert the new object before the closing `];` of the array.

Do not change any existing entries. Do not add comments. Do not add external dependencies.
