const articles = [
  {
    id: 1,
    title: "How the James Webb Space Telescope Works",
    summary:
      "A look at the mirror design, infrared imaging, and what JWST has already revealed about the early universe.",
    content: `The James Webb Space Telescope, launched December 25, 2021, is the most powerful space observatory ever built. At its heart is a 6.5-meter primary mirror composed of 18 hexagonal gold-plated beryllium segments — more than six times the light-collecting area of Hubble. That gold coating is deliberate: it maximizes reflectivity at infrared wavelengths, where Webb does most of its work.

Unlike Hubble, which observes primarily in visible and ultraviolet light, Webb operates across near- and mid-infrared wavelengths (0.6 to 28 micrometers). Infrared light passes through dust clouds that block visible light, letting Webb peer inside stellar nurseries and the cores of galaxies. It also captures the heavily redshifted light of the most distant galaxies — objects so far away that their light has been traveling for over 13 billion years, stretched from ultraviolet into the infrared by the expansion of the universe.

To detect this faint heat radiation, Webb's instruments must be kept extraordinarily cold. A five-layer sunshield the size of a tennis court blocks heat from the Sun, Earth, and Moon, holding the telescope at around −233°C (−387°F).

Since beginning science operations in 2022, Webb has delivered remarkable results: the deepest infrared view of the universe, the first direct detection of carbon dioxide in an exoplanet's atmosphere, and images of galaxies that formed within 300 million years of the Big Bang — reshaping our understanding of early cosmic history.`,
    author: "Editorial Team",
    date: "2025-11-15",
  },
  {
    id: 2,
    title: "Why Sleep Matters for Learning and Memory",
    summary:
      "What happens in your brain overnight, and why skipping sleep quietly undoes the studying you did that day.",
    content: `Sleep is not passive downtime — it is when the brain does much of its most important work. During the hours you sleep, neural circuits that fired during the day are replayed and reorganized, converting fragile short-term impressions into durable long-term memories.

The process depends on sleep's distinct stages. During non-REM slow-wave sleep — the deep, dreamless stages — the hippocampus, the brain's short-term memory hub, systematically reactivates the day's experiences and transfers them to the neocortex for permanent storage. Characteristic bursts of neural activity called sleep spindles help bind new information into existing knowledge networks.

REM sleep, which intensifies during the later cycles of the night, serves a different but complementary role. Brain imaging shows the prefrontal cortex goes quiet while emotional and associative regions remain highly active — the conditions for creative insight, flexible thinking, and the processing of emotionally charged memories. Cutting a night short preferentially reduces REM, which is why even moderate sleep restriction blunts creative problem-solving the next day.

The practical implications are clear. Students who sleep after studying recall significantly more than those who stay awake for the same period. A 90-minute nap taken between a learning session and a test can nearly double retention. Chronic sleep deprivation gradually shrinks the hippocampus and impairs the formation of new memories. The research is unambiguous: for learning to stick, sleep is not optional — it is part of the process.`,
    author: "Editorial Team",
    date: "2025-12-02",
  },
  {
    id: 3,
    title: "How Black Holes Are Formed",
    summary:
      "How stars collapse under their own gravity to create black holes, and why supermassive varieties at galaxy centres remain one of astronomy's great open questions.",
    content: `A black hole is a region of space where gravity is so intense that nothing — not even light — can escape. Most black holes form from the death of massive stars, a process that begins when a star at least eight to twenty times the mass of the Sun exhausts its nuclear fuel.

For most of a star's life, the outward pressure from nuclear fusion in its core balances the inward pull of gravity. When the fuel runs out, that balance collapses. The core implodes in a fraction of a second, triggering a catastrophic explosion called a supernova. If the remaining core is massive enough — typically above three solar masses — gravity wins completely and the core continues to collapse past the density of a neutron star until it forms a singularity: a point of virtually infinite density. The boundary surrounding it, beyond which escape becomes impossible, is called the event horizon.

Not all black holes come from supernovae. Supermassive black holes, which anchor the centres of most galaxies including our own Milky Way, can contain millions or billions of solar masses. Their exact origin is still debated; they may have grown through mergers of smaller black holes, direct collapse of massive gas clouds in the early universe, or both.

Black holes cannot be seen directly, but astronomers detect them through their effects: the distortion of nearby light, the behaviour of orbiting stars, and gravitational waves produced when two black holes collide.`,
    author: "Editorial Team",
    date: "2026-05-13",
  },
  {
    id: 4,
    title: "The Science of Habit Formation and How to Build Better Habits",
    summary:
      "Why habits are so hard to break — and what neuroscience reveals about the most effective strategies for building new ones.",
    content: `Every habit you have — good or bad — follows the same three-step pattern: a cue, a routine, and a reward. A cue is any trigger that signals your brain to act, the routine is the behaviour itself, and the reward is the payoff that tells your brain the loop is worth repeating. Over time, this cycle becomes hardwired, shifting control from the conscious, deliberate prefrontal cortex to the basal ganglia — a deeper brain structure that handles automatic, patterned behaviour. This "chunking" of routines frees up mental energy for more demanding tasks.

Dopamine, the neurotransmitter linked to motivation and pleasure, is the key driver behind this process. It spikes not just when you receive a reward but in anticipation of it — which is why craving forms before the behaviour, not after. This anticipatory dopamine release is what makes habits so self-reinforcing and, at times, so hard to break.

Research shows that habit formation depends on repetition in stable contexts, not on motivation or willpower. On average, a new behaviour takes around 66 days to feel automatic, though this varies widely by person and complexity.

Practical strategies include "habit stacking" — anchoring a new behaviour to an existing one — and designing your environment to reduce friction. Want to exercise more? Lay out your workout clothes the night before. The science is clear: small, consistent changes in context beat bursts of willpower every time.`,
    author: "Editorial Team",
    date: "2026-05-13",
  },
];

export default articles;
