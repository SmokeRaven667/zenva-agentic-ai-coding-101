# CLAUDE.md

This file gives Claude Code context about the project.

## Project

A beginner-friendly Todo app built with React and Vite, used as a starter
project for a Claude Code course. Students extend the app by adding missing
features — guided by Claude Code.

## Stack

| Layer       | Choice                        |
|-------------|-------------------------------|
| UI          | React 19                      |
| Bundler     | Vite 7                        |
| Styling     | CSS Modules (plain CSS only)  |
| Tests       | Vitest + Testing Library      |
| Persistence | localStorage                  |

No backend. No routing. No auth. No external UI libraries.

## Commands

| Command           | Purpose                          |
|-------------------|----------------------------------|
| `npm run dev`     | Start dev server (localhost:5173)|
| `npm run build`   | Production build                 |
| `npm test`        | Run tests in watch mode          |
| `npm run test:ui` | Open the Vitest browser UI       |

## Conventions

- All state lives in `App.jsx`; components receive data and callbacks as props
- One component per file; its CSS module lives in the same directory
- Task shape: `{ id: string, text: string, completed: boolean }`
- See `/docs/ui.md` for styling rules
- See `/docs/data-fetching.md` for state and persistence rules

## Critical Rules

- Magic numbers and configuration values must be extracted into a dedicated file under `src/utils/` — never hardcode them inline inside a component
