import styles from './TaskItem.module.css'
import { playCompleteSound } from '../utils/audio'

export default function TaskItem({ task, onToggle, onDelete }) {
  const handleToggle = () => {
    if (!task.completed) playCompleteSound()
    onToggle(task.id)
  }

  return (
    <li className={`${styles.item} ${task.completed ? styles.completed : ''}`}>
      {/* onChange={() => onToggle(task.id)} */}
      <input
        type="checkbox"
        className={styles.checkbox}
        checked={task.completed}
        onChange={handleToggle}
        aria-label={`Mark "${task.text}" as ${task.completed ? 'active' : 'complete'}`}
      />
      <span className={styles.text}>{task.text}</span>
      <button
        className={styles.deleteButton}
        onClick={() => onDelete(task.id)}
        aria-label={`Delete "${task.text}"`}
      >
        ✕
      </button>
    </li>
  )
}
