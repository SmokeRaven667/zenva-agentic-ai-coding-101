import styles from './TaskNote.module.css'

export default function TaskNote({ note }) {
  return (
    <div className={styles.note}>
      <span className={styles.text}>{note.text}</span>
    </div>
  )
}
