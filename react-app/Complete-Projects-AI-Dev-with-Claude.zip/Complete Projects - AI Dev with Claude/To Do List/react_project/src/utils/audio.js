const FREQUENCY_START = 880
const FREQUENCY_END = 1320
const FREQUENCY_RAMP_DURATION = 0.1
const GAIN_INITIAL = 0.3
const GAIN_FINAL = 0.001
const SOUND_DURATION = 0.3

export function playCompleteSound() {
  const ctx = new AudioContext()
  const osc = ctx.createOscillator()
  const gain = ctx.createGain()
  osc.connect(gain)
  gain.connect(ctx.destination)
  osc.type = 'sine'
  osc.frequency.setValueAtTime(FREQUENCY_START, ctx.currentTime)
  osc.frequency.exponentialRampToValueAtTime(FREQUENCY_END, ctx.currentTime + FREQUENCY_RAMP_DURATION)
  gain.gain.setValueAtTime(GAIN_INITIAL, ctx.currentTime)
  gain.gain.exponentialRampToValueAtTime(GAIN_FINAL, ctx.currentTime + SOUND_DURATION)
  osc.start(ctx.currentTime)
  osc.stop(ctx.currentTime + SOUND_DURATION)
}
