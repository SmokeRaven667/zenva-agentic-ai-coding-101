const articles = [
  {
    id: 1,
    title: "How the James Webb Space Telescope Works",
    summary:
      "A look at the mirror design, infrared imaging, and what JWST has already revealed about the early universe.",
    content: `The James Webb Space Telescope, launched December 25, 2021, is the most powerful space observatory ever built. At its heart is a 6.5-meter primary mirror composed of 18 hexagonal gold-plated beryllium segments — more than six times the light-collecting area of Hubble. That gold coating is deliberate: it maximizes reflectivity at infrared wavelengths, where Webb does most of its work.

Unlike Hubble, which observes primarily in visible and ultraviolet light, Webb operates across near- and mid-infrared wavelengths (0.6 to 28 micrometers). Infrared light passes through dust clouds that block visible light, letting Webb peer inside stellar nurseries and the cores of galaxies. It also captures the heavily redshifted light of the most distant galaxies — objects so far away that their light has been traveling for over 13 billion years, stretched from ultraviolet into the infrared by the expansion of the universe.

To detect this faint heat radiation, Webb's instruments must be kept extraordinarily cold. A five-layer sunshield the size of a tennis court blocks heat from the Sun, Earth, and Moon, holding the telescope at around −233°C (−387°F).

Since beginning science operations in 2022, Webb has delivered remarkable results: the deepest infrared view of the universe, the first direct detection of carbon dioxide in an exoplanet's atmosphere, and images of galaxies that formed within 300 million years of the Big Bang — reshaping our understanding of early cosmic history.`,
    author: "Editorial Team",
    date: "2025-11-15",
  },
  {
    id: 2,
    title: "Why Sleep Matters for Learning and Memory",
    summary:
      "What happens in your brain overnight, and why skipping sleep quietly undoes the studying you did that day.",
    content: `Sleep is not passive downtime — it is when the brain does much of its most important work. During the hours you sleep, neural circuits that fired during the day are replayed and reorganized, converting fragile short-term impressions into durable long-term memories.

The process depends on sleep's distinct stages. During non-REM slow-wave sleep — the deep, dreamless stages — the hippocampus, the brain's short-term memory hub, systematically reactivates the day's experiences and transfers them to the neocortex for permanent storage. Characteristic bursts of neural activity called sleep spindles help bind new information into existing knowledge networks.

REM sleep, which intensifies during the later cycles of the night, serves a different but complementary role. Brain imaging shows the prefrontal cortex goes quiet while emotional and associative regions remain highly active — the conditions for creative insight, flexible thinking, and the processing of emotionally charged memories. Cutting a night short preferentially reduces REM, which is why even moderate sleep restriction blunts creative problem-solving the next day.

The practical implications are clear. Students who sleep after studying recall significantly more than those who stay awake for the same period. A 90-minute nap taken between a learning session and a test can nearly double retention. Chronic sleep deprivation gradually shrinks the hippocampus and impairs the formation of new memories. The research is unambiguous: for learning to stick, sleep is not optional — it is part of the process.`,
    author: "Editorial Team",
    date: "2025-12-02",
  },
];

export default articles;
